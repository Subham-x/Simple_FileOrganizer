// Google Apps Script for handling feedback form submissions
// This script should be deployed as a web app

function doPost(e) {
  try {
    // Parse the JSON data from the request
    const data = JSON.parse(e.postData.contents);
    
    // Get or create the feedback spreadsheet
    const spreadsheet = getOrCreateSpreadsheet();
    const sheet = spreadsheet.getActiveSheet();
    
    // Prepare data for insertion
    const rowData = [
      new Date(data.timestamp),
      data.email,
      data.replyBack === 'true' ? 'Yes' : 'No',
      data.topic,
      data.feedbackType,
      data.description
    ];
    
    // Add data to spreadsheet
    sheet.appendRow(rowData);
    
    // Send email notification
    sendEmailNotification(data);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify({status: 'success'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    // Log error and return error response
    console.error('Error processing feedback:', error);
    return ContentService
      .createTextOutput(JSON.stringify({status: 'error', message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function getOrCreateSpreadsheet() {
  const spreadsheetName = 'Website Feedback';
  
  // Try to find existing spreadsheet
  const files = DriveApp.getFilesByName(spreadsheetName);
  
  if (files.hasNext()) {
    // Open existing spreadsheet
    const file = files.next();
    return SpreadsheetApp.openById(file.getId());
  } else {
    // Create new spreadsheet
    const spreadsheet = SpreadsheetApp.create(spreadsheetName);
    const sheet = spreadsheet.getActiveSheet();
    
    // Set up headers
    const headers = [
      'Timestamp',
      'Email',
      'Reply Back',
      'Topic',
      'Feedback Type',
      'Description'
    ];
    
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    
    // Format header row
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#4285f4');
    headerRange.setFontColor('white');
    
    // Auto-resize columns
    sheet.autoResizeColumns(1, headers.length);
    
    // Set up email trigger for new submissions
    ScriptApp.newTrigger('onFormSubmit')
      .spreadsheet(spreadsheet)
      .onFormSubmit()
      .create();
    
    return spreadsheet;
  }
}

function sendEmailNotification(data) {
  // Replace with your email address
  const recipientEmail = "hyper.devstudio@gmail.com";
  
  const subject = `New Website Feedback: ${data.topic}`;
  
  const htmlBody = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #667eea, #764ba2); padding: 30px; border-radius: 12px; color: white; text-align: center; margin-bottom: 20px;">
        <h1 style="margin: 0; font-size: 24px;">💬 New Feedback Received</h1>
      </div>
      
      <div style="background: #f8f9ff; padding: 30px; border-radius: 12px; border: 1px solid #e1e5f7;">
        <div style="margin-bottom: 20px;">
          <strong style="color: #667eea;">📧 Email:</strong>
          <span style="margin-left: 10px;">${data.email}</span>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong style="color: #667eea;">↩️ Reply Requested:</strong>
          <span style="margin-left: 10px;">${data.replyBack === 'true' ? '✅ Yes' : '❌ No'}</span>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong style="color: #667eea;">📝 Topic:</strong>
          <span style="margin-left: 10px;">${data.topic}</span>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong style="color: #667eea;">🏷️ Type:</strong>
          <span style="margin-left: 10px; padding: 4px 12px; background: #667eea; color: white; border-radius: 20px; font-size: 12px;">
            ${getFeedbackTypeLabel(data.feedbackType)}
          </span>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong style="color: #667eea;">💬 Description:</strong>
          <div style="margin-top: 10px; padding: 15px; background: white; border-radius: 8px; border-left: 4px solid #667eea;">
            ${data.description}
          </div>
        </div>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e1e5f7; color: #666; font-size: 12px;">
          <strong>Submitted:</strong> ${new Date(data.timestamp).toLocaleString()}
        </div>
      </div>
    </div>
  `;
  
  const plainTextBody = `
New Website Feedback Received

Email: ${data.email}
Reply Requested: ${data.replyBack === 'true' ? 'Yes' : 'No'}
Topic: ${data.topic}
Type: ${getFeedbackTypeLabel(data.feedbackType)}

Description:
${data.description}

Submitted: ${new Date(data.timestamp).toLocaleString()}
  `;
  
  try {
    MailApp.sendEmail({
      to: recipientEmail,
      subject: subject,
      htmlBody: htmlBody,
      body: plainTextBody
    });
  } catch (error) {
    console.error('Failed to send email notification:', error);
  }
}

function getFeedbackTypeLabel(type) {
  switch (type) {
    case 'feedback':
      return '💭 General Feedback';
    case 'feature_request':
      return '🚀 Feature Request';
    case 'feature_like':
      return '❤️ Feature Appreciation';
    default:
      return type;
  }
}

// Trigger function for spreadsheet updates (alternative method)
function onFormSubmit(e) {
  if (!e || !e.values) return;
  
  const feedback = e.values;
  const email = "hyper.devstudio@gmail.com"; // Replace with your email
  const subject = "New Website Feedback Submitted";
  
  const message = `
New feedback received:

Timestamp: ${feedback[0]}
Email: ${feedback[1]}
Reply Back: ${feedback[2]}
Topic: ${feedback[3]}
Feedback Type: ${feedback[4]}
Description: ${feedback[5]}
  `;
  
  try {
    MailApp.sendEmail(email, subject, message);
  } catch (error) {
    console.error('Failed to send email:', error);
  }
}

// Test function to verify the script works
function testScript() {
  const testData = {
    email: "test@example.com",
    replyBack: "true",
    topic: "Test Feedback",
    feedbackType: "feedback",
    description: "This is a test feedback submission.",
    timestamp: new Date().toISOString()
  };
  
  sendEmailNotification(testData);
  console.log("Test email sent successfully!");
}