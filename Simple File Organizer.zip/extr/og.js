const fs = require("fs")
const path = require("path")

console.warn("Searching Files...\n");
const files = fs.readdirSync(__dirname)             // ---- 1. Extracts all files names with extension (name.ext) and make it ARRAY.


for (let i = 0; i < files.length; i++) {

    let ext = files[i].split(".")[files[i].split(".").length-1]          
    // ---- 2. As ".splits()" splits a string from separator detected(like a dot or comma) ["logs.txt"->['logs', 'txt] and converts to ARRAY, ['logs', 'txt].
            // So logic inside [square_bracket] is getting INDEX: Total ".length" of splited ARRAY - 1 
                // ^^^^ It results a index: let 5-1=4th index. 
                            // E.G ==== Useful for "note.date.day.txt" picks 4-1=3 and i.e 3rd INDEX (txt)
            // Its equals to: @@ string.split(".")[splitted-"files" array INDEX] @@
    // ^^^^ It extracts the EXTENSION, by selecting last string separated by dot(.)

    if (fs.existsSync(ext)){
        console.log("Dirictory exists for: " + ext);
        fs.rename(files[i], path.join(ext, files[i]), (err)=> err? console.warn("Error for: "+ files[i]):console.log("Moved"))

        // ---- 3. Moves the file using "fs.rename()"
                    // ^^^^ It takes: ---- fs.rename(curr_path, new_path, (err)), all paths with ext, "myPath/note.txt".
                // 3.2 NOTE: "arr.path()" is different from "path.join('notes', 'demo.txt')", it joins like(notes/demo.txt)

    }
    else if (ext != "js") {
      fs.mkdirSync(ext)
      console.log("Created directory for: " + ext);
    }
    else {
        console.log("file is JavaScript.");
    }
    
}
